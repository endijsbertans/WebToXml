class script2:
    script = '''
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">    
<style>

/* List */
ul {
  top: 40px;
  position: absolute;
  left: 10px;
  counter-reset: index;  
  padding: 0;
  max-width: 400px;
  color: white;
  height:70%
}

/* List element */
li {
  counter-increment: index; 
  display: flex;
  align-items: center;
  padding: 12px 0;
  box-sizing: border-box;
}

/* Element counter */
li::before {
  content: counters(index, ".", decimal-leading-zero);
  font-size: 1.5rem;
  text-align: right;
  font-weight: bold;
  min-width: 50px;
  padding-right: 12px;
  font-variant-numeric: tabular-nums;
  align-self: flex-start;
  background-image: linear-gradient(to bottom, aquamarine, orangered);
  background-attachment: fixed;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* Element separation */
li + li {
  border-top: 1px solid rgba(255,255,255,0.2);
}
@use postcss-preset-env {
  stage: 0;
  autoprefixer: {
    grid: true;
  }
  browsers: last 2 versions
}
    html, body {
      
      display: flex;
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 15px;
      color:white;
      }
      form {
      
      border: 5px solid #f1f1f1;
      }
      input[type=text], input[type=password] {
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      }
      button {
      background-color: #8ebf42;
      color: white;
      padding: 14px 0;
      margin: 10px 0;
      border: none;
      cursor: grabbing;
      width: 100%;
      }
      h1 {
      text-align:center;
      fone-size:18;
      }
      button:hover {
      opacity: 0.8;
      }
      .formcontainer {
      
      text-align: left;
      margin: 24px 50px 12px;
      }
      .container {
      padding: 16px 0;
      text-align:left;
      }
      span.psw {
      float: right;
      padding-top: 9px;
      padding-right: 15px;
      }
      /* Change styles for span on extra small screens */
      @media screen and (max-width: 300px) {
      span.psw {
      display: block;
      float: none;
      }  

  </style>
'''
    form = '''
<form action="?" method="GET">
    <h1>Web to xml to S3 </h1>
        <div class="formcontainer">
            <hr/>
            <div class="container">
                 <label style="color:white;"><strong>Link</strong></label>
                <input type="text" id="url" name="url" ><br><br>

            </div>
        <button type="submit">Download</button>
  

      
        </div>
</form>
    
    
    '''