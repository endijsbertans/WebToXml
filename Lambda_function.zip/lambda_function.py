import json
from urllib.parse import urlparse
from urllib.parse import unquote
import urllib.request
import boto3
from htmlVar import script2
try:
    from urllib import request
except ImportError:
    import urllib
    
    

    
    
s3 = boto3.client('s3') # s3 bucket
array = ["Start Of Hystory"] # define global array, to store download history
wow = 'Start Of Hystory' # define string that prints history, and makes it easier to understand history




def lambda_handler(event, context):
    global wow
    global array
# Both variables get called in ^

    css = script2.script
    query = event['queryStringParameters']
    form = script2.form
# HTML code gets galled in and put into string, also query gets defined ^

    if len(query) == 0:
# if connected, push website to user, and define html code ^

        welcome = f'''
<html>

  <head>
    {css}
  </head>
  
  <body bgcolor=”#000133">
  
      <ul>
         {wow}
      </ul>
      
    <div style="padding-top:200px;">
         {form}
    </div>
    
  </body>
  
</html> 
'''
        wow = ''
        return {
        'statusCode': 200, 
        'headers': {"Content-Type":"text/html"},
        'body': welcome
        }

# returns html code, and if types link, sends it to download code        

    else:
        Url = query['url']
        
        url = unquote(Url)
# makes link readable ^

        response = request.urlopen(url)
        XML = response.read()
        XML = XML.decode("UTF-8")
# Downloads code ^

        o = urlparse(url)
# makes url into three sections, from witch o.netloc is the pages name^

        s3.put_object(Bucket='webxmlstorage', Key=o.netloc+'.xml', Body=XML)
# pushes the downloaded website to my s3 bucket ^
        
        event['queryStringParameters'] = ''
# resets query ^ so you can download different files
     
        jauns = o.netloc+ ' downloaded to bucket! ' 
        array.append(jauns)
# writes in array the downloaded file name plus informative text ^

        for x in array:
            
            wow = f"<li>{x+wow}</li>"
# writes out array on string wow, with some html code ^

        return lambda_handler(event, context)
# returns back to start ^